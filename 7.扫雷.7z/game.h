//
// Created by iTurning on 2020/11/13.
//

#ifndef INC_6__GAME_H
#define INC_6__GAME_H

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#pragma warning(dis)

#define  ROW 12
#define  COL 12
#define NUMS 20

void Menu();

void Game();

#endif //INC_6__GAME_H
