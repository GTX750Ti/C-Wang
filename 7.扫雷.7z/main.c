#include "game.h"

int main() {
    int quit = 0;
    int select = 0;
    while (!quit) {
        Menu();
        scanf("%d", &select);
        switch (select) {
            case 1:
                Game();
                break;
            case 2:
                quit = 1;
                printf("退出成功\n");
                break;
            default:
                break;
        }
    }
    return 0;
}