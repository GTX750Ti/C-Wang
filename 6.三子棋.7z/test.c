//
// Created by iTurning on 2020/11/11.
//
#include <stdio.h>
int main(){
    char arr[] = "China";
    for (int i = 0; i < sizeof(arr)/sizeof(arr[0]); ++i) {
        arr[i] += 4;
        printf("%c", arr[i]);
    }
    return 0;
}
