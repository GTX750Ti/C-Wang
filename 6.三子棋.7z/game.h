//
// Created by iTurning on 2020/11/11.
//

#ifndef C_GAME_H
#define C_GAME_H

#define COL 3
#define ROW 3
#define P_COLOR 'X'
#define C_COLOR 'O'
#define NEXT 'N'
#define DRAW 'D'

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

void Menu();
void Game();

#endif //C_GAME_H
