//
// Created by iTurning on 2020/11/11.
//
#include "game.h"

int main(){
    int quit = 0;
    int select = 0;
    while (!quit){
        Menu();
        scanf("%d", &select);
        switch (select) {
            case 1:
                Game();
                printf("要不要再来一把\n");
                break;
            case 2:
                quit = 1;
                break;
            default:
                printf("输入有误\n");
                break;
        }
    }
    return 0;
}
