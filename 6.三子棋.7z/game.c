#include "game.h"

void Menu() {
    printf("#######################\n");
    printf("##1.Play      2.Exit##\n");
    printf("#######################\n");
    printf("Please Select：》");
}

void ShowBoard(char board[][COL], int row, int col) {
    printf("  | 1 | 2 | 3 |\n");
    printf("----------------\n");
    for (int i = 0; i < row; ++i) {
        printf("%d |", i+1);
        for (int j = 0; j < col; ++j) {
            printf(" %c |", board[i][j]);
        }
        printf("\n----------------\n");
    }
}

void PlayerMove(char board[][COL], int row, int col) {
    int x = 0;
    int y = 0;
    int quit = 0;
    while (!quit) {
        printf("请输入你的位置：");
        scanf("%d %d", &x, &y);
        if (x < 1 || x > 3 || y < 1 || y > 3) {
            printf("你输入的坐标有误\n");
            continue;
        } else if (board[x - 1][y - 1] != ' ') {
            printf("你输入的坐标已经被占用\n");
        } else {
            board[x - 1][y - 1] = P_COLOR;
            break;
        }
    }
}

char Judge(char board[][COL], int row, int col) {
    //行
    for (int i = 0; i < ROW; ++i) {
        if (board[i][0] == board[i][1] && \
        board[i][1] == board[i][2] && \
        board[i][0] != ' ') {
            return board[i][0];
        }
    }

    //列
    for (int j = 0; j < COL; ++j) {
        if (board[0][j] == board[1][j] && \
            board[1][j] == board[2][j] && \
            board[0][j] != ' ') {
            return board[0][j];
        }
    }

    //撇
    if (board[0][0] == board[1][1] && \
            board[1][1] == board[2][2] && \
            board[0][0] != ' ') {
        return board[0][0];
    }

    //捺
    if (board[0][2] == board[1][1] && \
            board[1][1] == board[2][0] && \
            board[0][2] != ' ') {
        return board[0][2];
    }

    //正在下
    for (int i = 0; i < ROW; ++i) {
        for (int j = 0; j < COL; ++j) {
            if (board[i][j] == ' ') {
                return NEXT;
            }
        }
    }

    //和棋
    return DRAW;
}

void ComputerMove(char board[][COL], int row, int col) {
    while (1) {
        int x = rand() % ROW;
        int y = rand() % COL;
        if (board[x][y] == ' ') {
            board[x][y] = 'O';
            break;
        }
    }
}

void Game() {
    srand((unsigned int) time(NULL));
    char board[ROW][COL];
    //InitBoard(board, ROW, COL);
    memset(board, ' ', sizeof(board));
    char result = 'x';
    do {
        ShowBoard(board, ROW, COL);
        PlayerMove(board, ROW, COL);
        result = Judge(board, ROW, COL);
        if (result != NEXT) {
            break;
        }
        ComputerMove(board, ROW, COL);
        result = Judge(board, ROW, COL);
        if (result != NEXT) {
            break;
        }
    } while (1);
    if (P_COLOR == result) {
        printf("你赢了\n");
        ShowBoard(board, ROW, COL);
    } else if (C_COLOR == result) {
        printf("你输了\n");
        ShowBoard(board, ROW, COL);
    } else {
        printf("平局\n");
        ShowBoard(board, ROW, COL);
    }
}
