//
// Created by zxy on 2020/11/2.
//
#include <stdio.h>

////n的阶乘
//int Fact(int n) {
//    int ret = 1;
//    for (int i = n; i >= 1; --i) {
//        ret *= i;
//        /*
//         * 1
//         * 1 2
//         * 1 2 6
//         */
//    }
//    return ret;
//}
//
//int FactSum(int start, int end){
//    int sum = 0;
//    for (int i = start; i <= end; ++i) {
//        sum += Fact(i);
//    }
//    return sum;
//}
///*
// * for (n = 1; n < 10; n++){
// *      for (i = 0; i < n; ++i){
// *          ret *= i;
// *      }
// *      sum += ret;
// * }
// */
//
//int main() {
//    int start = 1;
//    int end = 5;
//    int n = 5;
//    int ret = Fact(n);
//    int sum = FactSum(start, end);
//    printf("ret = %d\n", ret);
//    printf("sum = %d\n", sum);
//    return 0;
//}










//二分查找
//int BinSearch(int arr[], int num, int target) {
//    int start = 0;
//    int end = num-1;
//    while (start <= end) {
//        int mid = (start + end) / 2;
//        if (arr[mid] > target) {
//            end = mid - 1;
//        } else if (arr[mid] < target) {
//            start = mid + 1;
//        } else {
//            return mid;
//        }
//    }
//}
//
//int main() {
//    int target = 1;
//    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//    int num = sizeof(arr) / sizeof(arr[0]);
//    int index = BinSearch(arr, num, target);
//    printf("index = %d\n", index);
//    return 0;
//}









//多个字符两端移动，向中间汇聚
//void Show(){
//    char content[] = "Hello World, Hello China";
//    char lable[]   = "########################";
//    int len = sizeof(content)/sizeof(content[0]);
//    int start = 0;
//    int end = 0;
//    printf("%s\r", lable);
//    for (start = 0, end = len-1;  start <= end; start++, end--) {
//        lable[start] = content[start];
//        lable[end] = content[end];
//        printf("%s\r", lable);
//    }
//}
//int main(){
//    Show();
//    return 0;
//}







//用户密码输入三次则报错
//#define NAME "tom"
//#define PASSWD "123"
//
//#include <string.h>
//
//int Login(int times) {
//    char name[64];
//    char passwd[64];
//    int ret = -1;
//    do {
//        printf("请输入你的帐号：");
//        scanf("%s", name);
//        printf("请输入你的密码：");
//        scanf("%s", passwd);
//        if (strcmp(name, NAME) == 0 && strcmp(passwd, PASSWD) == 0) {
//            ret = 1;
//            break;
//        }else{
//            times--;
//            printf("你还有%d次机会\n", times);
//        }
//        if (times == 0){
//            printf("不好意思，需要等待%d次才能再次尝试\n", 30);
////            Sleep(30000);
//            times = 3;
//        }
//    } while (1);
//}
//
//int main() {
//    int times = 3;
//    int ret = Login(times);
//    if (1 == ret) {
//        printf("登录成功\n");
//    } else {
//        printf("不好意思，登录失败\n");
//    }
//    return 0;
//}

//#include <stdio.h>
//#include <math.h>
//
//int is_PrimeNum(int num) {
//    int i = 0;
//    for (i = 2; i <= sqrt(num); i++) {
//        if (num % i == 0) {
//            return 0;
//        }
//    }
//    if (i > sqrt(num)) {
//        return 1;
//    }
//}
//
//int main() {
//    int num = 3;
//    int ret = is_PrimeNum(num);
//    if (ret == 1) {
//        printf("是素数\n");
//    } else {
//        printf("不是素数\n");
//    }
//}
