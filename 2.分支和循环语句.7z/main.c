#include <stdio.h>

/*
 * 分支语句
 * if
 * switch
 * 循环语句
 * while
 * for
 * do while
 *
 * goto
 */
#define _AGE_ 18
//int main() {
////    printf("你多大了：");
////    int age = 0;
////    scanf("%d", &age);
////    if (age < _AGE_){
////        printf("你还是少年\n");
////    }
////    else if (age >= 18 && age < 30){
////        printf("青年\n");
////    }
////    else if (age >= 40 && age < 50){
////        printf("中年\n");
////    }
////    else{
////        printf("老年\n");
////    }
//
//
//
//
//
////    int a = 0;
////    int b = 1;
////    if (a == b)
////        if (b == 2)
////            printf("b==2\n");
////        else
////            printf("a != 0\n");
//
//
//
//
//
//    int x = 1;
//    while (x <= 100){
//        if (x & 1){
//            printf("%d ", x);
//        }
//        x++;
//    }
//    return 0;
//}









/*
 * switch(整形表达式)
 * {
 * 语句项
 * }
 *
 * 语句项：
 * case 整形常量表达式:
 *      语句;
 *
 * switch必须搭配break才能实现真正的分支
 */
//int main(){
//    int day = 0;
//    printf("请输入:");
//    scanf("%d", &day);
//    switch (day) {
//        case 1:
//            printf("星期一!\n");
//            break;
//        case 2:
//            printf("星期二!\n");
//            break;
//        case 3:
//            printf("星期三!\n");
//            break;
//        case 4:
//            printf("星期四!\n");
//            break;
//        case 5:
//            printf("星期五!\n");
//            break;
//        case 6:
//            printf("星期六!\n");
//            break;
//        case 7:
//            printf("星期日!\n");
//            break;
//        default:
//            printf("输入错误\n");
//            break;
//    }
//    return 0;
//}






//int main(){
//    int n = 1;
//    int m = 2;
//    switch (n) {
//        case 1:
//            m++;
//        case 2:
//            n++;
//        case 3:
//            switch (n) {
//                case 1:
//                    n++;
//                case 2:
//                    m++;
//                    n++;
//                    break;
//            }
//        case 4:
//            m++;
//            break;
//        default:
//            break;
//    }
//    printf("m=%d, n=%d\n", m, n);
//    return 0;
//}







//int main(){
////    int i = 1;
////    while (i <= 10){
////        i++;
////        if (i == 7){
//////            break;//跳出循环，结束该循环
////            continue;//结束本轮循环，一般不直接结束循环，继续下一次循环
////        }
////        printf("%d\n", i);
////    }
//
//
//
//
//
//    int count = 0;
//    while (1){
//        printf("%d\n", count);
//        count++;
//        if (10 == count){
//            continue;
//        }
//    }
//    return 0;
//}







//int main(){
//    int ch;
//    //一般在输入输出的时候，对应输入的内容都是字符串！！！
//    while ((ch=getchar()) != EOF){
//        if (ch <= '9' && ch >= '0'){
//            putchar(ch);//command+z结束
//        }
//    }
//    return 0;
//}








//int main(){
//    for (int i = 0; i < 10; ++i) {
//        if (5 == i){
//            printf("out!\n");
//            continue;
//        }
//        printf("%d\n", i);
//    }
//    return 0;
//}








//int main(){
//    int x = 100;
//    int a = (printf("hello\n"), x = 200, x == 100);
//    printf("%d, %d\n", x, a);
//}






//int main(){
//    int x = 0;
//    int y = 0;
//    for(x = 5, y = 10; x < 10 && y < 20; x++, y++){
//        printf("%d, %d\n", x, y);
//    }
//    return 0;
//}







//int main() {
//    int i = 0;
//    int k = 0;
//    for (i = 0, k = 0; k = 0; k++, i++) {
//        k++;
//        printf(".\n");
//    }
//    printf("end\n");
//    return 0;
//}






