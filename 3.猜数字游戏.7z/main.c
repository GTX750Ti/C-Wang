#include "game.h"

int main() {
    int quit = 0;
    while (!quit){
        Menu();
        int select = 0;
        scanf("%d", &select);
        switch (select) {
            case 1:
                Login();
                printf("再来一盘\n");
                break;
            case 2:
                quit = 1;
                printf("Bye~退出游戏！\n");
                break;
            default:
                printf("输入有误！\n");
                break;
        }
    }
    return 0;
}
