//
// Created by zxy on 2020/11/4.
//

#ifndef C_HEAD_H
#define C_HEAD_H

#endif //C_HEAD_H

#define RANGE 100

#pragma once//防止头文件被重复包含，方法1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
void Menu();
void Game();
void Login();
