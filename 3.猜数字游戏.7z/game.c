//
// Created by zxy on 2020/11/4.
//
#include "game.h"

void Login() {
    char username[64];//egg
    char password[64];//666
    int count = 0;
    do {
        printf("请输入EggBrother:");
        scanf("%s", &username);
        printf("请输入666:");
        scanf(" %s", &password);
        if (strcmp(username, "EggBrother") == 0) {
            if (strcmp(password, "666") == 0){
                printf("超级无敌蛋蛋蛋启动\n");
                Game();
            }else {
                printf("密码输入错误【该怎么形容蛋哥呢？】\n");
            }
        } else {
            printf("用户名输入错误【提示：蛋哥英文单词】\n");
        }
        count++;
        printf("还有%d次机会\n", 3-count);
        if (count == 3) {
            printf("给你机会，你不中用，一年后再来找蛋哥\n");
        }
    } while (count < 3);
}

void Menu() {
    printf("##########################\n");
    printf("##   1.Play     2.Exit  ##\n");
    printf("##########################\n");
    printf("Please Select:");
}

void Game() {
    srand((unsigned int) time(NULL));
    int r = rand() % RANGE + 1;
    printf("我已经准备好了，你来吧\n");
    while (1) {
        int n = 0;
        printf("你猜：");
        scanf("%d", &n);
        if (n < r) {
            printf("猜小了\n");
        } else if (n == r) {
            printf("猜对了\n");
            break;
        } else {
            printf("猜大了\n");
        }
    }
}
